import{E as a,h as s}from"./index-8tBGr4HX.js";const p=a({name:"QSpace",setup(){const e=s("div",{class:"q-space"});return()=>e}});export{p as Q};
