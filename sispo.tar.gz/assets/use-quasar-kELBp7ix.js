import{a,bm as r}from"./index-8tBGr4HX.js";function u(){return a(r)}export{u};
