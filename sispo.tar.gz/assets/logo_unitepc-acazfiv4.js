const s="/assets/logo_unitepc-BhytD7ag.png";export{s as _};
